package pe.edu.upeu.padron;

import javafx.application.Application;

/** Lanzador para ejecutar el proyecto desde Maven o IntelliJ. */
public class App {
    public static void main(String[] args) { Application.launch(PadronApp.class, args); }
}
