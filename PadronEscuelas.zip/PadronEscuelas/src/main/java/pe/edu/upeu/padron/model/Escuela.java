package pe.edu.upeu.padron.model;

public class Escuela {
    private final long id;
    private String nombre;
    private NivelEducativo nivel;
    private String claveCentro;
    private String direccion;
    private int matricula;

    public Escuela(long id, String nombre, NivelEducativo nivel, String claveCentro, String direccion, int matricula) {
        this.id = id;
        actualizar(nombre, nivel, claveCentro, direccion, matricula);
    }
    public void actualizar(String nombre, NivelEducativo nivel, String claveCentro, String direccion, int matricula) {
        if (nombre == null || nombre.isBlank()) throw new IllegalArgumentException("Ingresa el nombre del plantel.");
        if (nivel == null) throw new IllegalArgumentException("Selecciona un nivel educativo.");
        if (claveCentro == null || claveCentro.isBlank()) throw new IllegalArgumentException("Ingresa la clave de centro de trabajo.");
        if (direccion == null || direccion.isBlank()) throw new IllegalArgumentException("Ingresa la dirección.");
        if (matricula < 0) throw new IllegalArgumentException("La matrícula no puede ser negativa.");
        this.nombre = nombre.trim();
        this.nivel = nivel;
        this.claveCentro = claveCentro.trim().toUpperCase();
        this.direccion = direccion.trim();
        this.matricula = matricula;
    }
    public long getId() { return id; }
    public String getNombre() { return nombre; }
    public NivelEducativo getNivel() { return nivel; }
    public String getClaveCentro() { return claveCentro; }
    public String getDireccion() { return direccion; }
    public int getMatricula() { return matricula; }
}
