package pe.edu.upeu.padron.model;

public enum NivelEducativo {
    PREESCOLAR("Preescolar"), PRIMARIA("Primaria"), SECUNDARIA("Secundaria"), PREPARATORIA("Preparatoria");
    private final String nombre;
    NivelEducativo(String nombre) { this.nombre = nombre; }
    @Override public String toString() { return nombre; }
}
