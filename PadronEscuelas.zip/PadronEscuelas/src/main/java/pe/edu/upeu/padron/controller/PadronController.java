package pe.edu.upeu.padron.controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import pe.edu.upeu.padron.model.*;
import pe.edu.upeu.padron.repository.EscuelaRepository;
import pe.edu.upeu.padron.service.EscuelaService;

public class PadronController {
    @FXML private TableView<Escuela> tabla;
    @FXML private TextField nombre;
    @FXML private ComboBox<NivelEducativo> nivel;
    @FXML private TextField clave;
    @FXML private TextField direccion;
    @FXML private TextField matricula;
    @FXML private ComboBox<String> filtro;
    @FXML private Label modo;
    @FXML private Label cantidadResultados;
    private final EscuelaService service = new EscuelaService(new EscuelaRepository());
    private Escuela seleccionada;

    @FXML private void initialize() {
        nivel.setItems(FXCollections.observableArrayList(NivelEducativo.values()));
        filtro.setItems(FXCollections.observableArrayList("Todos", "Preescolar", "Primaria", "Secundaria", "Preparatoria"));
        filtro.getSelectionModel().selectFirst();
        tabla.getColumns().addAll(col("ID", e -> "" + e.getId()), col("Plantel", Escuela::getNombre),
                col("Nivel", e -> e.getNivel().toString()), col("Clave de centro", Escuela::getClaveCentro),
                col("Dirección", Escuela::getDireccion), col("Matrícula", e -> "" + e.getMatricula()));
        tabla.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        filtro.valueProperty().addListener((obs, antes, despues) -> { limpiar(); refrescar(); });
        tabla.getSelectionModel().selectedItemProperty().addListener((obs, antes, escuela) -> {
            if (escuela == null) return;
            seleccionada = escuela;
            nombre.setText(escuela.getNombre());
            nivel.setValue(escuela.getNivel());
            clave.setText(escuela.getClaveCentro());
            direccion.setText(escuela.getDireccion());
            matricula.setText("" + escuela.getMatricula());
            modo.setText("Editando escuela #" + escuela.getId());
        });
        refrescar();
    }
    private TableColumn<Escuela, String> col(String titulo, java.util.function.Function<Escuela, String> valor) {
        TableColumn<Escuela, String> columna = new TableColumn<>(titulo);
        columna.setCellValueFactory(d -> new SimpleStringProperty(valor.apply(d.getValue())));
        return columna;
    }
    @FXML private void guardar() {
        try {
            int alumnos = Integer.parseInt(matricula.getText().trim());
            if (seleccionada == null) service.registrar(nombre.getText(), nivel.getValue(), clave.getText(), direccion.getText(), alumnos);
            else service.modificar(seleccionada.getId(), nombre.getText(), nivel.getValue(), clave.getText(), direccion.getText(), alumnos);
            limpiar();
            refrescar();
        } catch (NumberFormatException ex) { aviso("La matrícula debe ser un número entero."); }
        catch (IllegalArgumentException ex) { aviso(ex.getMessage()); }
    }
    @FXML private void eliminar() {
        if (seleccionada == null) { aviso("Selecciona una escuela en la tabla."); return; }
        Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION, "¿Eliminar la escuela seleccionada?", ButtonType.YES, ButtonType.NO);
        if (confirmacion.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;
        service.eliminar(seleccionada.getId());
        limpiar();
        refrescar();
    }
    @FXML private void limpiar() {
        seleccionada = null;
        tabla.getSelectionModel().clearSelection();
        nombre.clear(); nivel.getSelectionModel().clearSelection(); clave.clear(); direccion.clear(); matricula.clear();
        modo.setText("Nueva escuela");
    }
    private void refrescar() {
        NivelEducativo elegido = filtro.getSelectionModel().getSelectedIndex() <= 0 ? null : NivelEducativo.values()[filtro.getSelectionModel().getSelectedIndex() - 1];
        var visibles = service.filtrar(elegido);
        tabla.getItems().setAll(visibles);
        cantidadResultados.setText("Escuelas mostradas: " + visibles.size());
    }
    private void aviso(String mensaje) { new Alert(Alert.AlertType.WARNING, mensaje).showAndWait(); }
}
