package pe.edu.upeu.padron;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class PadronApp extends Application {
    @Override public void start(Stage stage) throws Exception {
        stage.setTitle("Padrón de escuelas públicas");
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/view/padron.fxml")), 1150, 650));
        stage.show();
    }
}
