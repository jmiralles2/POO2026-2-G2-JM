package pe.edu.upeu.padron.service;

import java.util.List;
import pe.edu.upeu.padron.model.*;
import pe.edu.upeu.padron.repository.EscuelaRepository;

public class EscuelaService {
    private final EscuelaRepository repo;
    public EscuelaService(EscuelaRepository repo) { this.repo = repo; }
    public List<Escuela> listar() { return repo.listar(); }
    public List<Escuela> filtrar(NivelEducativo nivel) {
        return repo.listar().stream().filter(e -> nivel == null || e.getNivel() == nivel).toList();
    }
    public Escuela registrar(String nombre, NivelEducativo nivel, String clave, String direccion, int matricula) {
        validarClaveUnica(clave, -1);
        Escuela escuela = new Escuela(repo.nuevoId(), nombre, nivel, clave, direccion, matricula);
        repo.guardar(escuela);
        return escuela;
    }
    public Escuela modificar(long id, String nombre, NivelEducativo nivel, String clave, String direccion, int matricula) {
        Escuela escuela = repo.buscar(id).orElseThrow(() -> new IllegalArgumentException("Escuela no encontrada."));
        validarClaveUnica(clave, id);
        escuela.actualizar(nombre, nivel, clave, direccion, matricula);
        return escuela;
    }
    public void eliminar(long id) {
        if (!repo.eliminar(id)) throw new IllegalArgumentException("Escuela no encontrada.");
    }
    private void validarClaveUnica(String clave, long idActual) {
        if (clave == null || clave.isBlank()) throw new IllegalArgumentException("Ingresa la clave de centro de trabajo.");
        boolean repetida = repo.listar().stream().anyMatch(e -> e.getId() != idActual && e.getClaveCentro().equalsIgnoreCase(clave.trim()));
        if (repetida) throw new IllegalArgumentException("La clave de centro de trabajo ya está registrada.");
    }
}
