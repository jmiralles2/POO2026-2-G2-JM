package pe.edu.upeu.padron.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import pe.edu.upeu.padron.model.Escuela;

/** Catálogo en memoria, sin base de datos. */
public class EscuelaRepository {
    private final List<Escuela> escuelas = new ArrayList<>();
    private long siguienteId = 1;
    public long nuevoId() { return siguienteId++; }
    public void guardar(Escuela escuela) { escuelas.add(escuela); }
    public List<Escuela> listar() { return new ArrayList<>(escuelas); }
    public Optional<Escuela> buscar(long id) { return escuelas.stream().filter(e -> e.getId() == id).findFirst(); }
    public boolean eliminar(long id) { return escuelas.removeIf(e -> e.getId() == id); }
}
