# Padrón de escuelas públicas — Ejercicio 24

Proyecto independiente en JavaFX y Maven. Requiere JDK 21. Abrir esta carpeta (la que contiene `pom.xml`) como proyecto Maven y ejecutar `mvn javafx:run`. En IntelliJ, importar `pom.xml` como proyecto Maven y ejecutar `App.java` si se prefiere el botón Run; no ejecutar `PadronApp.java` directamente.

La aplicación registra nombre del plantel, nivel educativo, clave de centro de trabajo, dirección y matrícula total. Permite listar, seleccionar y modificar, eliminar con confirmación y filtrar por nivel. La clave de centro de trabajo debe ser única. Se utiliza un `ArrayList` en memoria: los datos se pierden al cerrar la aplicación.
